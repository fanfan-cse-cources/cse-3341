class Scanner {
	
	// Constructor should open the file and find the first token
	Scanner(String filename) {
		
	}

	// nextToken should advance the scanner to the next token
	public void nextToken() {
		
	}

	// currentToken should return the current token
	public Core currentToken() {
		return 0;
	}

	// If the current token is ID, return the string value of the identifier
	// Otherwise, return value does not matter
	public String getID() {
		return "";
	}

	// If the current token is CONST, return the numerical value of the constant
	// Otherwise, return value does not matter
	public int getCONST() {
		return 0;
	}

}